import streamlit as st

st.set_page_config(
    page_title="About Me",
    page_icon="👨‍💻"
)

st.write("""
# About Me
Let me introduce myself, I am
""")
st.write("Husna Rezal Dewantara, S.Kom")
st.write("I graduated from S-1 Computer Science, Lambung Mangkurat Univesity (Indonesia)")
st.write("2022")
st.write("You can contact me on [Instagram](https://www.instagram.com/rezaldwntr/) and [Linkedin](https://www.linkedin.com/in/husna-rezal-dewantara/)")
